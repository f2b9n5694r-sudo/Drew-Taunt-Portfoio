const y=document.querySelector('#year'); if(y)y.textContent=new Date().getFullYear();
const btn=document.querySelector('.menu-btn'), links=document.querySelector('.navlinks'); if(btn)btn.addEventListener('click',()=>links.classList.toggle('open'));
const obs=new IntersectionObserver(es=>es.forEach(e=>{if(e.isIntersecting)e.target.classList.add('visible')}),{threshold:.13});document.querySelectorAll('.reveal').forEach(el=>obs.observe(el));
const glow=document.querySelector('.cursor-glow'); window.addEventListener('mousemove',e=>{if(glow){glow.style.left=e.clientX+'px';glow.style.top=e.clientY+'px'}});
